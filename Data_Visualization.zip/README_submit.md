# Flights Data Exploration
## by Thien Huynh


## Dataset

> The dataset name is "Airline On-Time Performance Data". This dataset reports flights in the United States, including carriers, arrival and departure delays, and reasons for delays, from 1987 to 2008. The dataset can be downloaded from website https://www.transtats.bts.gov/ directly. In this project, data flights in 2007 and plane-data are used. Flights in 2007 has 29 columns and 7,453,215 rows to describe information of each flight. Plane data has 9 columns and 5029 rows to highlight the information of aircrafts.


## Summary of Findings

> In this exploration, the main focus was about On-time performance analysis. Deep-dive analysis on cancelled flights was not performed due to the number of cancellation had only 2% in comparison total flights.


## Key Insights for Presentation

> The main focus on how much delayed flights and the features effecting to this flights. Firstly, the overview of On-time performance flights (% delayed, % cancelled flights and overview distribution). Secondly, based on the results, the focus should be on departure delay and find out a correlation between variables (airports, manufacturer, and time). Finally, the most delay type should be demonstrated to have a deep-dive on delayed flights.